﻿using System;

namespace Rpg
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            var app = new AppManager();
            app.getMenu();
            app.waitCommand();
        }
    }
}
