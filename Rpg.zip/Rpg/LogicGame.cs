﻿using System;

public class LogicGame
{
	public void classes()
	{
		classes = mage;
	}
}
