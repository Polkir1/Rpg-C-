﻿using System;

namespace Rpg
{
    internal class AppManager
    {
        public void getMenu()
        {
            // Используем @ перед строкой, чтобы не экранировать каждый слэш и переносы строк
            Console.WriteLine("|\t   /Rpg game\\\t\t|\r\n|\t   1.Начать игру\t|\r\n|\t   2.Настройки \t\t|\r\n|\t   3.Выйти\t\t|\r\n");
        }

        public void waitCommand()
        {
            while (true)
            {
                Console.Write("Введите команду: ");

                // .Trim() убирает пробелы в начале и конце строки (например, "1 " станет "1")
                // ?. защищает от ошибки, если ReadLine вдруг вернет null
                string userCommand = Console.ReadLine()?.Trim();

                if (userCommand == "3")
                {
                    Console.WriteLine("Конец игры");
                    break;
                }

                HandleCommandMenu(userCommand);
            }
        }

        public void HandleCommandMenu(string userCommand)
        {
            // Проверка на пустую строку (если просто нажали Enter)
            if (string.IsNullOrEmpty(userCommand))
            {
                Console.WriteLine("Вы ничего не ввели. Пожалуйста, выберите пункт меню.");
                return;
            }

            switch (userCommand)
            {
                case "1":
                    Console.WriteLine("Игра начинается!");
                    // Здесь будет логика старта игры
                    break;
                case "2":
                    Console.WriteLine("|          Настройки\t\t|\r\n|\tСложность\t\t|\r\n|  1.сложная \t\t\t|\r\n|  2.средняя\t\t\t|\r\n|  3.легкий\t\t\t|\r\n");
                    // Здесь будет логика настроек
                    break;
                default:
                    // Этот блок сработает, если ввели не 1, 2 или 3
                    Console.WriteLine($"Неизвестная команда '{userCommand}'. Пожалуйста, введите 1, 2 или 3.");
                    break;
            }
        }
    }
}
